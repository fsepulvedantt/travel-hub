(function() {
  const API_RESERVAS = '/o/reservas';
  let viajeInfo = {};

  // Obtener parámetros de la URL
  function obtenerParametrosURL() {
    const urlParams = new URLSearchParams(window.location.search);
    return {
      viajeIdIda: urlParams.get('viajeIdIda'),
      viajeIdVuelta: urlParams.get('viajeIdVuelta')
    };
  }

  // Formatear precio
  function formatearPrecio(precio) {
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS',
      minimumFractionDigits: 2
    }).format(precio);
  }

  // Formatear fecha completa
  function formatearFechaCompleta(fechaString) {
    const timestamp = typeof fechaString === 'string' ? parseInt(fechaString) : fechaString;
    const fecha = new Date(timestamp);
    return fecha.toLocaleDateString('es-AR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  // Formatear número de tarjeta (agregar espacios)
  function formatearTarjeta(input) {
    let valor = input.value.replace(/\s/g, '');
    let formato = valor.match(/.{1,4}/g);
    input.value = formato ? formato.join(' ') : valor;
    
    // Actualizar display de la tarjeta
    const display = valor.replace(/\s/g, '');
    if (display.length > 0) {
      const asteriscos = '•'.repeat(Math.max(0, 16 - display.length));
      const mostrados = display.substring(Math.max(0, display.length - 4));
      document.getElementById('displayNumero').textContent = asteriscos + mostrados;
    } else {
      document.getElementById('displayNumero').textContent = '•••• •••• •••• ••••';
    }
  }

  // Formatear vencimiento (agregar /)
  function formatearVencimiento(input) {
    let valor = input.value.replace(/\D/g, '');
    if (valor.length >= 2) {
      input.value = valor.substring(0, 2) + '/' + valor.substring(2, 4);
      document.getElementById('displayVencimiento').textContent = input.value;
    } else {
      input.value = valor;
      document.getElementById('displayVencimiento').textContent = valor ? valor + '/' : 'MM/AA';
    }
  }

  // Actualizar CVV con animación
  function actualizarCVV(input) {
    let valor = input.value.replace(/\D/g, '');
    if (valor.length > 0) {
      document.getElementById('displayCVV').textContent = '•'.repeat(valor.length);
    } else {
      document.getElementById('displayCVV').textContent = '•••';
    }
  }

  // Activar flip de tarjeta al hacer foco en CVV
  function activarFlip() {
    const tarjeta = document.getElementById('tarjetaCredito');
    const cvvInput = document.getElementById('cvv');
    
    cvvInput.addEventListener('focus', () => {
      tarjeta.classList.add('flipped');
    });
    
    cvvInput.addEventListener('blur', () => {
      tarjeta.classList.remove('flipped');
    });
  }

  // Validar formato de DNI
  function validarDNI(dni) {
    return /^[0-9]{7,8}$/.test(dni);
  }

  // Validar formato de email
  function validarEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  // Inicializar formulario
  function inicializarFormulario() {
    const urlParams = obtenerParametrosURL();

    if (!urlParams.viajeIdIda) {
      mostrarError('No se encontró información del viaje. Por favor, seleccione un viaje desde la lista.');
      return;
    }

    // Obtener viajes de sessionStorage
    const viajeIda = JSON.parse(sessionStorage.getItem('viajeIda'));
    const viajeVuelta = urlParams.viajeIdVuelta ? JSON.parse(sessionStorage.getItem('viajeVuelta')) : null;
    const tipoReserva = sessionStorage.getItem('tipoReserva') || 'IDA';

    if (!viajeIda) {
      mostrarError('No se encontró información del viaje de ida.');
      return;
    }

    // Guardar en viajeInfo
    viajeInfo = {
      viajeIdIda: viajeIda.viajeId,
      viajeIdVuelta: viajeVuelta ? viajeVuelta.viajeId : null,
      tipoReserva: tipoReserva,
      viajeIda: viajeIda,
      viajeVuelta: viajeVuelta
    };

    // Mostrar resumen
    let resumenHTML = `
      <div class="mb-3 p-3 border rounded bg-light">
        <h6 class="text-primary mb-2"><i class="bi bi-arrow-right-circle"></i> Viaje de Ida</h6>
        <p class="mb-1"><strong>Ruta:</strong> ${viajeIda.origen} → ${viajeIda.destino}</p>
        <p class="mb-1"><strong>Empresa:</strong> ${viajeIda.empresa}</p>
        <p class="mb-1"><strong>Salida:</strong> ${formatearFechaCompleta(viajeIda.fechaSalida)}</p>
        <p class="mb-0"><strong>Precio:</strong> ${formatearPrecio(viajeIda.precio)}</p>
      </div>
    `;

    if (viajeVuelta) {
      resumenHTML += `
        <div class="mb-3 p-3 border rounded bg-light">
          <h6 class="text-success mb-2"><i class="bi bi-arrow-left-circle"></i> Viaje de Vuelta</h6>
          <p class="mb-1"><strong>Ruta:</strong> ${viajeVuelta.origen} → ${viajeVuelta.destino}</p>
          <p class="mb-1"><strong>Empresa:</strong> ${viajeVuelta.empresa}</p>
          <p class="mb-1"><strong>Salida:</strong> ${formatearFechaCompleta(viajeVuelta.fechaSalida)}</p>
          <p class="mb-0"><strong>Precio:</strong> ${formatearPrecio(viajeVuelta.precio)}</p>
        </div>
      `;
    }

    const precioTotal = viajeIda.precio + (viajeVuelta ? viajeVuelta.precio : 0);
    resumenHTML += `
      <div class="text-end mt-3">
        <h5 class="text-success">Total: ${formatearPrecio(precioTotal)}</h5>
      </div>
    `;

    document.getElementById('rutaResumen').innerHTML = resumenHTML;
    // Ocultar el elemento precioResumen ya que ahora lo mostramos en rutaResumen
    const precioResumenElement = document.getElementById('precioResumen');
    if (precioResumenElement) {
      precioResumenElement.style.display = 'none';
    }

    // Formateo automático de campos
    const inputTarjeta = document.getElementById('numeroTarjeta');
    inputTarjeta.addEventListener('input', () => formatearTarjeta(inputTarjeta));

    const inputVencimiento = document.getElementById('vencimiento');
    inputVencimiento.addEventListener('input', () => formatearVencimiento(inputVencimiento));

    // Solo números en DNI y CVV
    document.getElementById('dni').addEventListener('input', function(e) {
      this.value = this.value.replace(/\D/g, '');
    });

    const inputCVV = document.getElementById('cvv');
    inputCVV.addEventListener('input', function(e) {
      this.value = this.value.replace(/\D/g, '');
      actualizarCVV(this);
    });

    // Autocompletar titular con nombre y actualizar display
    document.getElementById('nombre').addEventListener('blur', function() {
      const titular = document.getElementById('titular');
      if (!titular.value && this.value) {
        titular.value = this.value.toUpperCase();
        document.getElementById('displayTitular').textContent = this.value.toUpperCase();
      }
    });

    document.getElementById('titular').addEventListener('input', function() {
      document.getElementById('displayTitular').textContent = this.value.toUpperCase() || 'Tu Nombre';
    });

    // Activar flip de tarjeta
    activarFlip();

    // Botón cancelar
    document.getElementById('btnCancelar').addEventListener('click', () => {
      window.history.back();
    });

    // Submit del formulario
    document.getElementById('formReserva').addEventListener('submit', procesarReserva);

    // Botón volver al inicio en modal
    document.getElementById('btnVolverInicio').addEventListener('click', () => {
      window.location.href = '/web/travelhub';
    });

    // Cerrar modal al hacer click fuera
    const modal = document.getElementById('modalExito');
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          cerrarModal();
        }
      });
    }

    // Botón cerrar modal
    const btnCerrarModal = document.getElementById('btnCerrarModal');
    if (btnCerrarModal) {
      btnCerrarModal.addEventListener('click', cerrarModal);
    }
  }

  // Cerrar modal
  function cerrarModal() {
    const modal = document.getElementById('modalExito');
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
    window.location.href = '/web/travelhub';
  }

  // Procesar reserva
  async function procesarReserva(e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);

    // Validaciones
    const dni = formData.get('dni');
    const mail = formData.get('mail');

    if (!validarDNI(dni)) {
      mostrarError('El DNI debe tener 7 u 8 dígitos numéricos.');
      return;
    }

    if (!validarEmail(mail)) {
      mostrarError('Ingrese un email válido.');
      return;
    }

    // Mostrar procesando
    document.getElementById('procesandoMsg').style.display = 'block';
    document.getElementById('errorMsg').style.display = 'none';
    document.getElementById('btnConfirmar').disabled = true;

    // Simular delay de pasarela de pago (1-2 segundos)
    await new Promise(resolve => setTimeout(resolve, 1500));

    try {
      // Crear reserva
      const viajeIda = viajeInfo.viajeIda;
      const viajeVuelta = viajeInfo.viajeVuelta;
      
      const reservaData = {
        idViajeIda: parseInt(viajeInfo.viajeIdIda),
        idViajeVuelta: viajeInfo.viajeIdVuelta ? parseInt(viajeInfo.viajeIdVuelta) : 0,
        tipoReserva: viajeInfo.tipoReserva,
        origen: viajeIda.origen,
        destino: viajeIda.destino,
        fechaSalida: new Date(typeof viajeIda.fechaSalida === 'string' ? parseInt(viajeIda.fechaSalida) : viajeIda.fechaSalida).toISOString(),
        fechaLlegada: new Date(typeof viajeIda.fechaLlegada === 'string' ? parseInt(viajeIda.fechaLlegada) : viajeIda.fechaLlegada).toISOString(),
        mail: mail,
        dni: dni
      };

      const response = await fetch(API_RESERVAS, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(reservaData)
      });

      if (!response.ok) {
        throw new Error('Error al crear la reserva');
      }

      const reserva = await response.json();

      // Ocultar procesando
      document.getElementById('procesandoMsg').style.display = 'none';
      document.getElementById('btnConfirmar').disabled = false;

      // Mostrar modal de éxito
      mostrarExito(reserva.reservaId);

    } catch (error) {
      console.error('Error al procesar reserva:', error);
      document.getElementById('procesandoMsg').style.display = 'none';
      document.getElementById('btnConfirmar').disabled = false;
      mostrarError('Hubo un error al procesar su reserva. Por favor, intente nuevamente.');
    }
  }

  // Mostrar modal de éxito
  function mostrarExito(reservaId) {
    document.getElementById('codigoReserva').textContent = `#${reservaId}`;
    
    // Mostrar modal personalizado
    const modal = document.getElementById('modalExito');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  }

  // Mostrar mensaje de error
  function mostrarError(mensaje) {
    const errorDiv = document.getElementById('errorMsg');
    errorDiv.textContent = mensaje;
    errorDiv.style.display = 'block';
    
    // Scroll al error
    errorDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  // Inicializar cuando carga la página
  document.addEventListener('DOMContentLoaded', inicializarFormulario);
})();
